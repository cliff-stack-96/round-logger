import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, c as Download, i as Trash2, l as ChartColumn, o as Plus, r as TrendingUp, s as List, t as Upload } from "../_libs/lucide-react.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BeuL5try.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BUCKETS = [
	{
		label: "Under 2x",
		lo: 0,
		hi: 2
	},
	{
		label: "2x – 5x",
		lo: 2,
		hi: 5
	},
	{
		label: "5x – 10x",
		lo: 5,
		hi: 10
	},
	{
		label: "10x – 50x",
		lo: 10,
		hi: 50
	},
	{
		label: "50x+",
		lo: 50,
		hi: Infinity
	}
];
function mulberry32(seed) {
	let a = seed;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function sampleMultiplier(rand) {
	const roll = rand();
	if (roll < .52) return Math.round((1 + rand() * .95) * 100) / 100;
	if (roll < .78) return Math.round((2 + rand() * 2.8) * 100) / 100;
	if (roll < .9) return Math.round((5 + rand() * 4.5) * 100) / 100;
	if (roll < .98) return Math.round((10 + rand() * 28) * 100) / 100;
	return Math.round((50 + rand() * 180) * 100) / 100;
}
/** Fixed demo log so the first open is never empty. Replaced on import. */
function buildSampleRounds() {
	const rand = mulberry32(20261119);
	const base = Date.parse("2026-11-19T06:10:00.000Z");
	const rounds = [];
	let cursor = base;
	for (let i = 0; i < 96; i += 1) {
		cursor += 18e3 + Math.floor(rand() * 42e3);
		const multiplier = sampleMultiplier(rand);
		rounds.push({
			id: `sample-${i}`,
			at: new Date(cursor).toISOString(),
			multiplier
		});
	}
	return rounds;
}
function parseMultiplier(raw) {
	const cleaned = raw.trim().toLowerCase().replace(/x$/, "").replace(/,/g, "");
	if (!cleaned) return null;
	const value = Number(cleaned);
	if (!Number.isFinite(value) || value <= 0 || value > 1e5) return null;
	return Math.round(value * 100) / 100;
}
function parseStamp(raw) {
	const text = raw.trim().replace(/^"|"$/g, "");
	if (!text) return null;
	const parsed = Date.parse(text);
	if (Number.isNaN(parsed)) return null;
	return new Date(parsed).toISOString();
}
function parseLogText(text, fallbackStart = Date.now()) {
	const lines = text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
	const rounds = [];
	let clock = fallbackStart;
	lines.forEach((line, index) => {
		if (/^observed_at\b/i.test(line) || /^datetime\b/i.test(line) || /^time\b/i.test(line)) return;
		const cells = line.split(/[,;\t]/).map((cell) => cell.trim().replace(/^"|"$/g, ""));
		let at = null;
		let multiplier = null;
		if (cells.length >= 2) {
			at = parseStamp(cells[0]);
			multiplier = parseMultiplier(cells[1] ?? "");
			if (multiplier == null) {
				multiplier = parseMultiplier(cells[0] ?? "");
				at = parseStamp(cells[1] ?? "");
			}
		} else multiplier = parseMultiplier(cells[0] ?? line);
		if (multiplier == null) return;
		if (!at) {
			clock += 2e4;
			at = new Date(clock).toISOString();
		} else clock = Date.parse(at);
		rounds.push({
			id: `${at}-${multiplier}-${index}`,
			at,
			multiplier
		});
	});
	return rounds.sort((a, b) => a.at.localeCompare(b.at));
}
function mergeRounds(current, incoming) {
	const seen = new Set(current.map((round) => `${round.at}|${round.multiplier}`));
	const next = [...current];
	for (const round of incoming) {
		const key = `${round.at}|${round.multiplier}`;
		if (seen.has(key)) continue;
		seen.add(key);
		next.push(round);
	}
	return next.sort((a, b) => a.at.localeCompare(b.at));
}
function filterRounds(rounds, mode) {
	if (mode === "100") return rounds.slice(-100);
	if (mode === "all" || rounds.length === 0) return rounds;
	const cutoff = Date.parse(rounds[rounds.length - 1].at) - (mode === "24h" ? 864e5 : 2592e5);
	return rounds.filter((round) => Date.parse(round.at) >= cutoff);
}
function streakLengths(values, high = 5, low = 2) {
	const highStreaks = [];
	const lowStreaks = [];
	let highRun = 0;
	let lowRun = 0;
	const flush = () => {
		if (highRun > 0) highStreaks.push(highRun);
		if (lowRun > 0) lowStreaks.push(lowRun);
		highRun = 0;
		lowRun = 0;
	};
	for (const value of values) if (value >= high) {
		if (lowRun > 0) {
			lowStreaks.push(lowRun);
			lowRun = 0;
		}
		highRun += 1;
	} else if (value < low) {
		if (highRun > 0) {
			highStreaks.push(highRun);
			highRun = 0;
		}
		lowRun += 1;
	} else flush();
	flush();
	return {
		highStreaks,
		lowStreaks
	};
}
function analyze(rounds) {
	if (rounds.length === 0) return null;
	const values = rounds.map((round) => round.multiplier);
	const total = values.length;
	const sum = values.reduce((acc, value) => acc + value, 0);
	const gaps = [];
	let lastTen = -1;
	values.forEach((value, index) => {
		if (value >= 10) {
			if (lastTen >= 0) gaps.push(index - lastTen);
			lastTen = index;
		}
	});
	const byDay = /* @__PURE__ */ new Map();
	const byHour = /* @__PURE__ */ new Map();
	for (const round of rounds) {
		const date = new Date(round.at);
		const day = date.toISOString().slice(0, 10);
		const hour = `${day} ${String(date.getUTCHours()).padStart(2, "0")}:00`;
		const dayList = byDay.get(day) ?? [];
		dayList.push(round.multiplier);
		byDay.set(day, dayList);
		const hourList = byHour.get(hour) ?? [];
		hourList.push(round.multiplier);
		byHour.set(hour, hourList);
	}
	const mean = (list) => list.reduce((acc, value) => acc + value, 0) / list.length;
	const streaks = streakLengths(values);
	return {
		total,
		avg: sum / total,
		high: Math.max(...values),
		low: Math.min(...values),
		start: rounds[0].at,
		end: rounds[rounds.length - 1].at,
		count10: values.filter((value) => value >= 10).length,
		count50: values.filter((value) => value >= 50).length,
		avgGap10: gaps.length ? gaps.reduce((acc, value) => acc + value, 0) / gaps.length : 0,
		since10: lastTen < 0 ? total : total - 1 - lastTen,
		buckets: BUCKETS.map((bucket) => {
			const count = values.filter((value) => value >= bucket.lo && value < bucket.hi).length;
			return {
				label: bucket.label,
				count,
				pct: count / total * 100
			};
		}),
		highStreaks: streaks.highStreaks,
		lowStreaks: streaks.lowStreaks,
		daily: [...byDay.entries()].map(([day, list]) => ({
			day,
			count: list.length,
			avg: mean(list),
			max: Math.max(...list)
		})),
		hourly: [...byHour.entries()].map(([hour, list]) => ({
			hour,
			count: list.length,
			avg: mean(list)
		}))
	};
}
function toCsv(rounds) {
	const lines = ["observed_at,multiplier,event"];
	for (const round of rounds) lines.push(`${round.at},${round.multiplier.toFixed(2)}x,logged`);
	return lines.join("\n");
}
function formatX(value) {
	return `${value.toFixed(2)}x`;
}
function formatWhen(iso) {
	const date = new Date(iso);
	const pad = (n) => String(n).padStart(2, "0");
	return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())} UTC`;
}
function spanLabel(start, end) {
	const ms = Math.max(0, Date.parse(end) - Date.parse(start));
	const hours = Math.floor(ms / 36e5);
	const minutes = Math.floor(ms % 36e5 / 6e4);
	if (hours >= 48) return `${Math.floor(hours / 24)}d ${hours % 24}h`;
	if (hours > 0) return `${hours}h ${minutes}m`;
	return `${minutes}m`;
}
var useLogStore = create()(persist((set, get) => ({
	rounds: buildSampleRounds(),
	sample: true,
	filter: "all",
	hydrated: false,
	setFilter: (filter) => set({ filter }),
	replace: (rounds) => set({
		rounds,
		sample: false
	}),
	append: (rounds) => set({
		rounds: mergeRounds(get().rounds, rounds),
		sample: false
	}),
	clear: () => set({
		rounds: [],
		sample: false
	}),
	loadSample: () => set({
		rounds: buildSampleRounds(),
		sample: true,
		filter: "all"
	}),
	markHydrated: () => set({ hydrated: true })
}), {
	name: "round-log-v1",
	skipHydration: true,
	partialize: (state) => ({
		rounds: state.rounds,
		sample: state.sample,
		filter: state.filter
	})
}));
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "24h",
		label: "24h"
	},
	{
		id: "3d",
		label: "3 days"
	},
	{
		id: "100",
		label: "Last 100"
	}
];
var TABS = [
	{
		id: "overview",
		label: "Overview",
		icon: ChartColumn
	},
	{
		id: "trend",
		label: "Trend",
		icon: TrendingUp
	},
	{
		id: "history",
		label: "Rounds",
		icon: List
	},
	{
		id: "import",
		label: "Add",
		icon: Plus
	}
];
function tone(value) {
	if (value >= 10) return "text-mint";
	if (value >= 2) return "text-amber";
	return "text-coral";
}
function RoundLog() {
	const rounds = useLogStore((state) => state.rounds);
	const sample = useLogStore((state) => state.sample);
	const filter = useLogStore((state) => state.filter);
	const setFilter = useLogStore((state) => state.setFilter);
	const replace = useLogStore((state) => state.replace);
	const append = useLogStore((state) => state.append);
	const clear = useLogStore((state) => state.clear);
	const loadSample = useLogStore((state) => state.loadSample);
	const markHydrated = useLogStore((state) => state.markHydrated);
	const [tab, setTab] = (0, import_react.useState)("overview");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		Promise.resolve(useLogStore.persist.rehydrate()).then(() => markHydrated());
	}, [markHydrated]);
	const visible = (0, import_react.useMemo)(() => filterRounds(rounds, filter), [rounds, filter]);
	const stats = (0, import_react.useMemo)(() => analyze(visible), [visible]);
	function ingest(text, mode) {
		const parsed = parseLogText(text);
		if (parsed.length === 0) {
			setNotice("Nothing usable in that text. Use a CSV or one multiplier per line.");
			return;
		}
		if (mode === "replace") replace(parsed);
		else append(parsed);
		setDraft("");
		setNotice(`${parsed.length} rounds ${mode === "replace" ? "loaded" : "added"}. Saved on this device.`);
		setTab("overview");
	}
	function onFile(file, mode) {
		if (!file) return;
		const reader = new FileReader();
		reader.onload = () => ingest(String(reader.result ?? ""), mode);
		reader.readAsText(file);
	}
	function download() {
		const blob = new Blob([toCsv(rounds)], { type: "text/csv" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = "aviator_rounds.csv";
		link.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg-deep text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-5xl flex-col md:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-line bg-bg px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3 md:sticky md:top-0 md:h-dvh md:w-64 md:shrink-0 md:border-r md:border-b-0 md:px-5 md:py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.18em] text-faint uppercase",
						children: "On this phone"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-semibold tracking-tight",
						children: "Round Log"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Read the CSV from the computer recorder. Nothing here predicts the next round."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 hidden flex-col gap-1 md:flex",
						children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
							active: tab === item.id,
							onClick: () => setTab(item.id),
							children: item.label
						}, item.id))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 px-4 pt-4 pb-28 md:px-8 md:pt-6 md:pb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap items-center gap-2",
					children: [FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(item.id),
						className: `min-h-11 rounded-full px-4 text-sm ${filter === item.id ? "bg-amber text-amber-ink" : "bg-surface text-muted"}`,
						children: item.label
					}, item.id)), sample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border border-line px-3 py-2 text-xs text-faint",
						children: "Sample log — import yours to replace it"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border border-line px-3 py-2 text-xs text-mint",
						children: "Saved on this device"
					})]
				}), !stats ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					onSample: loadSample,
					onAdd: () => setTab("import")
				}) : tab === "overview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, { stats }) : tab === "trend" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trend, { rounds: visible }) : tab === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryList, { rounds: visible }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportPanel, {
					draft,
					notice,
					onDraft: setDraft,
					onFile,
					onIngest: ingest,
					onClear: () => {
						clear();
						setNotice("Log cleared on this device.");
					},
					onSample: loadSample,
					onDownload: download,
					hasRounds: rounds.length > 0
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 backdrop-blur md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-lg grid-cols-4 pb-[env(safe-area-inset-bottom)]",
				children: TABS.map((item) => {
					const Icon = item.icon;
					const active = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab(item.id),
						className: `flex min-h-14 flex-col items-center justify-center gap-1 text-xs ${active ? "text-amber" : "text-faint"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 18,
							strokeWidth: 1.75
						}), item.label]
					}, item.id);
				})
			})
		})]
	});
}
function NavButton({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `min-h-11 rounded-xl px-3 text-left text-sm ${active ? "bg-amber text-amber-ink" : "text-muted hover:bg-surface"}`,
		children
	});
}
function Empty({ onSample, onAdd }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "No rounds in this view"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Add a CSV from the desktop recorder, or load the sample log."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onAdd,
					className: "min-h-11 rounded-xl bg-amber px-4 text-sm font-medium text-amber-ink",
					children: "Add rounds"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onSample,
					className: "min-h-11 rounded-xl border border-line px-4 text-sm",
					children: "Load sample"
				})]
			})
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-surface px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-faint uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "num mt-1 text-2xl text-fg",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function Overview({ stats }) {
	const longestHigh = stats.highStreaks.length ? Math.max(...stats.highStreaks) : 0;
	const longestLow = stats.lowStreaks.length ? Math.max(...stats.lowStreaks) : 0;
	const avgHigh = stats.highStreaks.length ? stats.highStreaks.reduce((a, b) => a + b, 0) / stats.highStreaks.length : 0;
	const avgLow = stats.lowStreaks.length ? stats.lowStreaks.reduce((a, b) => a + b, 0) / stats.lowStreaks.length : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Rounds",
						value: String(stats.total),
						hint: spanLabel(stats.start, stats.end)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Average",
						value: formatX(stats.avg)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Highest",
						value: formatX(stats.high)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Lowest",
						value: formatX(stats.low)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-muted",
					children: "What the log actually shows"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-base leading-relaxed",
					children: [
						stats.buckets[0].pct.toFixed(0),
						"% landed under 2x. A 10x+ showed up ",
						stats.count10,
						" times",
						stats.avgGap10 > 0 ? `, about every ${stats.avgGap10.toFixed(1)} rounds` : "",
						".",
						" ",
						stats.since10 === 0 ? "The latest round was 10x or higher." : `${stats.since10} rounds have passed since the last 10x.`
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Distribution"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: stats.buckets.map((bucket) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: bucket.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "num text-muted",
							children: [
								bucket.count,
								" · ",
								bucket.pct.toFixed(1),
								"%"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 overflow-hidden rounded-full bg-bg-deep",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-amber",
							style: { width: `${Math.max(bucket.pct, bucket.count ? 2 : 0)}%` }
						})
					})] }, bucket.label))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-card border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Streaks"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "High runs (≥ 5x)",
								v: `${stats.highStreaks.length} · longest ${longestHigh} · avg ${avgHigh.toFixed(1)}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Low runs (< 2x)",
								v: `${stats.lowStreaks.length} · longest ${longestLow} · avg ${avgLow.toFixed(1)}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "50x and above",
								v: `${stats.count50} (${(stats.count50 / stats.total * 100).toFixed(1)}%)`
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-card border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Biggest each day"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: stats.daily.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-baseline justify-between gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: day.day
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "num",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: tone(day.max),
									children: formatX(day.max)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-2 text-faint",
									children: [day.count, " rnd"]
								})]
							})]
						}, day.day))
					})]
				})]
			})
		]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "num text-right",
			children: v
		})]
	});
}
function Trend({ rounds }) {
	const data = rounds.slice(-80).map((round, index) => ({
		i: index + 1,
		m: round.multiplier,
		label: formatWhen(round.at)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "text-sm font-medium",
				children: [
					"Last ",
					data.length,
					" multipliers"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-faint",
				children: "Amber marks the path. This is history, not a forecast."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-64",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data,
						margin: {
							top: 8,
							right: 4,
							left: 0,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "i",
								hide: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								width: 36,
								tick: {
									fill: "var(--color-faint)",
									fontSize: 11
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								contentStyle: {
									background: "var(--color-bg)",
									border: "1px solid var(--color-line)",
									borderRadius: 12,
									color: "var(--color-fg)"
								},
								formatter: (value) => [formatX(Number(value)), "Multiplier"],
								labelFormatter: (_, payload) => {
									return (payload?.[0]?.payload)?.label ?? "";
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "m",
								stroke: "var(--color-amber)",
								fill: "var(--color-amber)",
								fillOpacity: .18,
								strokeWidth: 2,
								dot: false
							})
						]
					})
				})
			})
		]
	});
}
function HistoryList({ rounds }) {
	const rows = [...rounds].reverse().slice(0, 80);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-card border border-line bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium",
				children: "Newest first"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-faint",
				children: [rows.length, " shown · times in UTC"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: rows.map((round) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3 last:border-b-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "num text-xs text-muted",
				children: formatWhen(round.at)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `num text-base ${tone(round.multiplier)}`,
				children: formatX(round.multiplier)
			})]
		}, round.id)) })]
	});
}
function ImportPanel({ draft, notice, onDraft, onFile, onIngest, onClear, onSample, onDownload, hasRounds }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-card border border-line bg-surface p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold",
					children: "Bring a log over"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Drop ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "num",
							children: "aviator_rounds.csv"
						}),
						" from the desktop recorder, or paste multipliers. The file stays in this browser — it is not uploaded."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex min-h-14 cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-line bg-bg-deep text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { size: 16 }),
						"Choose CSV",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: ".csv,text/csv,text/plain",
							className: "sr-only",
							onChange: (event) => onFile(event.target.files?.[0], "replace")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: draft,
					onChange: (event) => onDraft(event.target.value),
					placeholder: "2026-11-09T21:28:26+03:00,1.15x\n2.41x\n8.90x",
					className: "num mt-3 min-h-36 w-full rounded-xl border border-line bg-bg-deep p-3 text-sm text-fg outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onIngest(draft, "replace"),
						className: "min-h-11 rounded-xl bg-amber px-4 text-sm font-medium text-amber-ink",
						children: "Replace log"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onIngest(draft, "add"),
						className: "min-h-11 rounded-xl border border-line px-4 text-sm",
						children: "Add to log"
					})]
				}),
				notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-mint",
					children: notice
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-2 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onDownload,
					disabled: !hasRounds,
					className: "flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface text-sm disabled:opacity-40",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 16 }), " Export CSV"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onSample,
					className: "flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 16 }), " Sample log"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onClear,
					className: "flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface text-sm text-coral",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 16 }), " Clear"]
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoundLog, {});
}
//#endregion
export { Home as component };
