import { create } from "zustand";
import { persist } from "zustand/middleware";
import { buildSampleRounds, mergeRounds, type Round } from "@/lib/analyze";

export type FilterMode = "all" | "24h" | "3d" | "100";

type LogState = {
  rounds: Round[];
  sample: boolean;
  filter: FilterMode;
  hydrated: boolean;
  setFilter: (filter: FilterMode) => void;
  replace: (rounds: Round[]) => void;
  append: (rounds: Round[]) => void;
  clear: () => void;
  loadSample: () => void;
  markHydrated: () => void;
};

export const useLogStore = create<LogState>()(
  persist(
    (set, get) => ({
      rounds: buildSampleRounds(),
      sample: true,
      filter: "all",
      hydrated: false,
      setFilter: (filter) => set({ filter }),
      replace: (rounds) => set({ rounds, sample: false }),
      append: (rounds) => set({ rounds: mergeRounds(get().rounds, rounds), sample: false }),
      clear: () => set({ rounds: [], sample: false }),
      loadSample: () => set({ rounds: buildSampleRounds(), sample: true, filter: "all" }),
      markHydrated: () => set({ hydrated: true }),
    }),
    {
      name: "round-log-v1",
      skipHydration: true,
      partialize: (state) => ({
        rounds: state.rounds,
        sample: state.sample,
        filter: state.filter,
      }),
    },
  ),
);
