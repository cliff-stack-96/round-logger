export type Round = {
  id: string;
  at: string;
  multiplier: number;
};

export type Bucket = {
  label: string;
  count: number;
  pct: number;
};

export type DayRow = {
  day: string;
  count: number;
  avg: number;
  max: number;
};

export type HourRow = {
  hour: string;
  count: number;
  avg: number;
};

export type LogStats = {
  total: number;
  avg: number;
  high: number;
  low: number;
  start: string;
  end: string;
  count10: number;
  count50: number;
  avgGap10: number;
  since10: number;
  buckets: Bucket[];
  highStreaks: number[];
  lowStreaks: number[];
  daily: DayRow[];
  hourly: HourRow[];
};

const BUCKETS: { label: string; lo: number; hi: number }[] = [
  { label: "Under 2x", lo: 0, hi: 2 },
  { label: "2x – 5x", lo: 2, hi: 5 },
  { label: "5x – 10x", lo: 5, hi: 10 },
  { label: "10x – 50x", lo: 10, hi: 50 },
  { label: "50x+", lo: 50, hi: Infinity },
];

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sampleMultiplier(rand: () => number): number {
  const roll = rand();
  if (roll < 0.52) return Math.round((1 + rand() * 0.95) * 100) / 100;
  if (roll < 0.78) return Math.round((2 + rand() * 2.8) * 100) / 100;
  if (roll < 0.9) return Math.round((5 + rand() * 4.5) * 100) / 100;
  if (roll < 0.98) return Math.round((10 + rand() * 28) * 100) / 100;
  return Math.round((50 + rand() * 180) * 100) / 100;
}

/** Fixed demo log so the first open is never empty. Replaced on import. */
export function buildSampleRounds(): Round[] {
  const rand = mulberry32(20261119);
  const base = Date.parse("2026-11-19T06:10:00.000Z");
  const rounds: Round[] = [];
  let cursor = base;
  for (let i = 0; i < 96; i += 1) {
    cursor += 18_000 + Math.floor(rand() * 42_000);
    const multiplier = sampleMultiplier(rand);
    rounds.push({
      id: `sample-${i}`,
      at: new Date(cursor).toISOString(),
      multiplier,
    });
  }
  return rounds;
}

export function parseMultiplier(raw: string): number | null {
  const cleaned = raw.trim().toLowerCase().replace(/x$/, "").replace(/,/g, "");
  if (!cleaned) return null;
  const value = Number(cleaned);
  if (!Number.isFinite(value) || value <= 0 || value > 100_000) return null;
  return Math.round(value * 100) / 100;
}

function parseStamp(raw: string): string | null {
  const text = raw.trim().replace(/^"|"$/g, "");
  if (!text) return null;
  const parsed = Date.parse(text);
  if (Number.isNaN(parsed)) return null;
  return new Date(parsed).toISOString();
}

export function parseLogText(text: string, fallbackStart = Date.now()): Round[] {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  const rounds: Round[] = [];
  let clock = fallbackStart;

  lines.forEach((line, index) => {
    if (/^observed_at\b/i.test(line) || /^datetime\b/i.test(line) || /^time\b/i.test(line)) {
      return;
    }

    const cells = line.split(/[,;\t]/).map((cell) => cell.trim().replace(/^"|"$/g, ""));
    let at: string | null = null;
    let multiplier: number | null = null;

    if (cells.length >= 2) {
      at = parseStamp(cells[0]);
      multiplier = parseMultiplier(cells[1] ?? "");
      if (multiplier == null) {
        multiplier = parseMultiplier(cells[0] ?? "");
        at = parseStamp(cells[1] ?? "");
      }
    } else {
      multiplier = parseMultiplier(cells[0] ?? line);
    }

    if (multiplier == null) return;

    if (!at) {
      clock += 20_000;
      at = new Date(clock).toISOString();
    } else {
      clock = Date.parse(at);
    }

    rounds.push({
      id: `${at}-${multiplier}-${index}`,
      at,
      multiplier,
    });
  });

  return rounds.sort((a, b) => a.at.localeCompare(b.at));
}

export function mergeRounds(current: Round[], incoming: Round[]): Round[] {
  const seen = new Set(current.map((round) => `${round.at}|${round.multiplier}`));
  const next = [...current];
  for (const round of incoming) {
    const key = `${round.at}|${round.multiplier}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(round);
  }
  return next.sort((a, b) => a.at.localeCompare(b.at));
}

export function filterRounds(rounds: Round[], mode: "all" | "24h" | "3d" | "100"): Round[] {
  if (mode === "100") return rounds.slice(-100);
  if (mode === "all" || rounds.length === 0) return rounds;
  const end = Date.parse(rounds[rounds.length - 1]!.at);
  const windowMs = mode === "24h" ? 24 * 60 * 60 * 1000 : 3 * 24 * 60 * 60 * 1000;
  const cutoff = end - windowMs;
  return rounds.filter((round) => Date.parse(round.at) >= cutoff);
}

function streakLengths(values: number[], high = 5, low = 2) {
  const highStreaks: number[] = [];
  const lowStreaks: number[] = [];
  let highRun = 0;
  let lowRun = 0;

  const flush = () => {
    if (highRun > 0) highStreaks.push(highRun);
    if (lowRun > 0) lowStreaks.push(lowRun);
    highRun = 0;
    lowRun = 0;
  };

  for (const value of values) {
    if (value >= high) {
      if (lowRun > 0) {
        lowStreaks.push(lowRun);
        lowRun = 0;
      }
      highRun += 1;
    } else if (value < low) {
      if (highRun > 0) {
        highStreaks.push(highRun);
        highRun = 0;
      }
      lowRun += 1;
    } else {
      flush();
    }
  }
  flush();
  return { highStreaks, lowStreaks };
}

export function analyze(rounds: Round[]): LogStats | null {
  if (rounds.length === 0) return null;
  const values = rounds.map((round) => round.multiplier);
  const total = values.length;
  const sum = values.reduce((acc, value) => acc + value, 0);
  const gaps: number[] = [];
  let lastTen = -1;
  values.forEach((value, index) => {
    if (value >= 10) {
      if (lastTen >= 0) gaps.push(index - lastTen);
      lastTen = index;
    }
  });

  const byDay = new Map<string, number[]>();
  const byHour = new Map<string, number[]>();
  for (const round of rounds) {
    const date = new Date(round.at);
    const day = date.toISOString().slice(0, 10);
    const hour = `${day} ${String(date.getUTCHours()).padStart(2, "0")}:00`;
    const dayList = byDay.get(day) ?? [];
    dayList.push(round.multiplier);
    byDay.set(day, dayList);
    const hourList = byHour.get(hour) ?? [];
    hourList.push(round.multiplier);
    byHour.set(hour, hourList);
  }

  const mean = (list: number[]) => list.reduce((acc, value) => acc + value, 0) / list.length;
  const streaks = streakLengths(values);

  return {
    total,
    avg: sum / total,
    high: Math.max(...values),
    low: Math.min(...values),
    start: rounds[0]!.at,
    end: rounds[rounds.length - 1]!.at,
    count10: values.filter((value) => value >= 10).length,
    count50: values.filter((value) => value >= 50).length,
    avgGap10: gaps.length ? gaps.reduce((acc, value) => acc + value, 0) / gaps.length : 0,
    since10: lastTen < 0 ? total : total - 1 - lastTen,
    buckets: BUCKETS.map((bucket) => {
      const count = values.filter((value) => value >= bucket.lo && value < bucket.hi).length;
      return { label: bucket.label, count, pct: (count / total) * 100 };
    }),
    highStreaks: streaks.highStreaks,
    lowStreaks: streaks.lowStreaks,
    daily: [...byDay.entries()].map(([day, list]) => ({
      day,
      count: list.length,
      avg: mean(list),
      max: Math.max(...list),
    })),
    hourly: [...byHour.entries()].map(([hour, list]) => ({
      hour,
      count: list.length,
      avg: mean(list),
    })),
  };
}

export function toCsv(rounds: Round[]): string {
  const lines = ["observed_at,multiplier,event"];
  for (const round of rounds) {
    lines.push(`${round.at},${round.multiplier.toFixed(2)}x,logged`);
  }
  return lines.join("\n");
}

export function formatX(value: number): string {
  return `${value.toFixed(2)}x`;
}

export function formatWhen(iso: string): string {
  const date = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getUTCFullYear()}-${pad(date.getUTCMonth() + 1)}-${pad(date.getUTCDate())} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())} UTC`;
}

export function spanLabel(start: string, end: string): string {
  const ms = Math.max(0, Date.parse(end) - Date.parse(start));
  const hours = Math.floor(ms / 3_600_000);
  const minutes = Math.floor((ms % 3_600_000) / 60_000);
  if (hours >= 48) return `${Math.floor(hours / 24)}d ${hours % 24}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}
