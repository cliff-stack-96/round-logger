import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  BarChart3,
  Download,
  List,
  Plus,
  RotateCcw,
  Trash2,
  TrendingUp,
  Upload,
} from "lucide-react";
import {
  analyze,
  filterRounds,
  formatWhen,
  formatX,
  parseLogText,
  spanLabel,
  toCsv,
  type Round,
} from "@/lib/analyze";
import { useLogStore, type FilterMode } from "@/lib/log-store";

type Tab = "overview" | "trend" | "history" | "import";

const FILTERS: { id: FilterMode; label: string }[] = [
  { id: "all", label: "All" },
  { id: "24h", label: "24h" },
  { id: "3d", label: "3 days" },
  { id: "100", label: "Last 100" },
];

const TABS: { id: Tab; label: string; icon: typeof BarChart3 }[] = [
  { id: "overview", label: "Overview", icon: BarChart3 },
  { id: "trend", label: "Trend", icon: TrendingUp },
  { id: "history", label: "Rounds", icon: List },
  { id: "import", label: "Add", icon: Plus },
];

function tone(value: number): string {
  if (value >= 10) return "text-mint";
  if (value >= 2) return "text-amber";
  return "text-coral";
}

export function RoundLog() {
  const rounds = useLogStore((state) => state.rounds);
  const sample = useLogStore((state) => state.sample);
  const filter = useLogStore((state) => state.filter);
  const setFilter = useLogStore((state) => state.setFilter);
  const replace = useLogStore((state) => state.replace);
  const append = useLogStore((state) => state.append);
  const clear = useLogStore((state) => state.clear);
  const loadSample = useLogStore((state) => state.loadSample);
  const markHydrated = useLogStore((state) => state.markHydrated);
  const [tab, setTab] = useState<Tab>("overview");
  const [draft, setDraft] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    void Promise.resolve(useLogStore.persist.rehydrate()).then(() => markHydrated());
  }, [markHydrated]);

  const visible = useMemo(() => filterRounds(rounds, filter), [rounds, filter]);
  const stats = useMemo(() => analyze(visible), [visible]);

  function ingest(text: string, mode: "replace" | "add") {
    const parsed = parseLogText(text);
    if (parsed.length === 0) {
      setNotice("Nothing usable in that text. Use a CSV or one multiplier per line.");
      return;
    }
    if (mode === "replace") replace(parsed);
    else append(parsed);
    setDraft("");
    setNotice(`${parsed.length} rounds ${mode === "replace" ? "loaded" : "added"}. Saved on this device.`);
    setTab("overview");
  }

  function onFile(file: File | undefined, mode: "replace" | "add") {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => ingest(String(reader.result ?? ""), mode);
    reader.readAsText(file);
  }

  function download() {
    const blob = new Blob([toCsv(rounds)], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "aviator_rounds.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-dvh bg-bg-deep text-fg">
      <div className="mx-auto flex min-h-dvh w-full max-w-5xl flex-col md:flex-row">
        <header className="border-b border-line bg-bg px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3 md:sticky md:top-0 md:h-dvh md:w-64 md:shrink-0 md:border-r md:border-b-0 md:px-5 md:py-6">
          <p className="text-xs tracking-[0.18em] text-faint uppercase">On this phone</p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">Round Log</h1>
          <p className="mt-2 text-sm text-muted">
            Read the CSV from the computer recorder. Nothing here predicts the next round.
          </p>
          <div className="mt-4 hidden flex-col gap-1 md:flex">
            {TABS.map((item) => (
              <NavButton key={item.id} active={tab === item.id} onClick={() => setTab(item.id)}>
                {item.label}
              </NavButton>
            ))}
          </div>
        </header>

        <main className="flex-1 px-4 pt-4 pb-28 md:px-8 md:pt-6 md:pb-10">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            {FILTERS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setFilter(item.id)}
                className={`min-h-11 rounded-full px-4 text-sm ${
                  filter === item.id
                    ? "bg-amber text-amber-ink"
                    : "bg-surface text-muted"
                }`}
              >
                {item.label}
              </button>
            ))}
            {sample ? (
              <span className="rounded-full border border-line px-3 py-2 text-xs text-faint">
                Sample log — import yours to replace it
              </span>
            ) : (
              <span className="rounded-full border border-line px-3 py-2 text-xs text-mint">
                Saved on this device
              </span>
            )}
          </div>

          {!stats ? (
            <Empty onSample={loadSample} onAdd={() => setTab("import")} />
          ) : tab === "overview" ? (
            <Overview stats={stats} />
          ) : tab === "trend" ? (
            <Trend rounds={visible} />
          ) : tab === "history" ? (
            <HistoryList rounds={visible} />
          ) : (
            <ImportPanel
              draft={draft}
              notice={notice}
              onDraft={setDraft}
              onFile={onFile}
              onIngest={ingest}
              onClear={() => {
                clear();
                setNotice("Log cleared on this device.");
              }}
              onSample={loadSample}
              onDownload={download}
              hasRounds={rounds.length > 0}
            />
          )}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 backdrop-blur md:hidden">
        <div className="mx-auto grid max-w-lg grid-cols-4 pb-[env(safe-area-inset-bottom)]">
          {TABS.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`flex min-h-14 flex-col items-center justify-center gap-1 text-xs ${
                  active ? "text-amber" : "text-faint"
                }`}
              >
                <Icon size={18} strokeWidth={1.75} />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

function NavButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`min-h-11 rounded-xl px-3 text-left text-sm ${
        active ? "bg-amber text-amber-ink" : "text-muted hover:bg-surface"
      }`}
    >
      {children}
    </button>
  );
}

function Empty({ onSample, onAdd }: { onSample: () => void; onAdd: () => void }) {
  return (
    <section className="rounded-card border border-line bg-surface p-6">
      <h2 className="text-lg font-semibold">No rounds in this view</h2>
      <p className="mt-2 text-sm text-muted">Add a CSV from the desktop recorder, or load the sample log.</p>
      <div className="mt-4 flex flex-wrap gap-2">
        <button type="button" onClick={onAdd} className="min-h-11 rounded-xl bg-amber px-4 text-sm font-medium text-amber-ink">
          Add rounds
        </button>
        <button type="button" onClick={onSample} className="min-h-11 rounded-xl border border-line px-4 text-sm">
          Load sample
        </button>
      </div>
    </section>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-card border border-line bg-surface px-4 py-3">
      <p className="text-xs tracking-wide text-faint uppercase">{label}</p>
      <p className="num mt-1 text-2xl text-fg">{value}</p>
      {hint ? <p className="mt-1 text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

function Overview({ stats }: { stats: NonNullable<ReturnType<typeof analyze>> }) {
  const longestHigh = stats.highStreaks.length ? Math.max(...stats.highStreaks) : 0;
  const longestLow = stats.lowStreaks.length ? Math.max(...stats.lowStreaks) : 0;
  const avgHigh = stats.highStreaks.length
    ? stats.highStreaks.reduce((a, b) => a + b, 0) / stats.highStreaks.length
    : 0;
  const avgLow = stats.lowStreaks.length
    ? stats.lowStreaks.reduce((a, b) => a + b, 0) / stats.lowStreaks.length
    : 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Rounds" value={String(stats.total)} hint={spanLabel(stats.start, stats.end)} />
        <Stat label="Average" value={formatX(stats.avg)} />
        <Stat label="Highest" value={formatX(stats.high)} />
        <Stat label="Lowest" value={formatX(stats.low)} />
      </div>

      <section className="rounded-card border border-line bg-surface p-4">
        <h2 className="text-sm font-medium text-muted">What the log actually shows</h2>
        <p className="mt-2 text-base leading-relaxed">
          {stats.buckets[0]!.pct.toFixed(0)}% landed under 2x. A 10x+ showed up {stats.count10} times
          {stats.avgGap10 > 0 ? `, about every ${stats.avgGap10.toFixed(1)} rounds` : ""}.{" "}
          {stats.since10 === 0
            ? "The latest round was 10x or higher."
            : `${stats.since10} rounds have passed since the last 10x.`}
        </p>
      </section>

      <section className="rounded-card border border-line bg-surface p-4">
        <h2 className="text-sm font-medium">Distribution</h2>
        <ul className="mt-3 space-y-3">
          {stats.buckets.map((bucket) => (
            <li key={bucket.label}>
              <div className="mb-1 flex justify-between text-sm">
                <span>{bucket.label}</span>
                <span className="num text-muted">
                  {bucket.count} · {bucket.pct.toFixed(1)}%
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-bg-deep">
                <div
                  className="h-full rounded-full bg-amber"
                  style={{ width: `${Math.max(bucket.pct, bucket.count ? 2 : 0)}%` }}
                />
              </div>
            </li>
          ))}
        </ul>
      </section>

      <div className="grid gap-3 md:grid-cols-2">
        <section className="rounded-card border border-line bg-surface p-4">
          <h2 className="text-sm font-medium">Streaks</h2>
          <dl className="mt-3 space-y-2 text-sm">
            <Row k="High runs (≥ 5x)" v={`${stats.highStreaks.length} · longest ${longestHigh} · avg ${avgHigh.toFixed(1)}`} />
            <Row k="Low runs (< 2x)" v={`${stats.lowStreaks.length} · longest ${longestLow} · avg ${avgLow.toFixed(1)}`} />
            <Row k="50x and above" v={`${stats.count50} (${((stats.count50 / stats.total) * 100).toFixed(1)}%)`} />
          </dl>
        </section>
        <section className="rounded-card border border-line bg-surface p-4">
          <h2 className="text-sm font-medium">Biggest each day</h2>
          <ul className="mt-3 space-y-2">
            {stats.daily.map((day) => (
              <li key={day.day} className="flex items-baseline justify-between gap-3 text-sm">
                <span className="text-muted">{day.day}</span>
                <span className="num">
                  <span className={tone(day.max)}>{formatX(day.max)}</span>
                  <span className="ml-2 text-faint">{day.count} rnd</span>
                </span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="text-muted">{k}</dt>
      <dd className="num text-right">{v}</dd>
    </div>
  );
}

function Trend({ rounds }: { rounds: Round[] }) {
  const data = rounds.slice(-80).map((round, index) => ({
    i: index + 1,
    m: round.multiplier,
    label: formatWhen(round.at),
  }));

  return (
    <section className="rounded-card border border-line bg-surface p-4">
      <h2 className="text-sm font-medium">Last {data.length} multipliers</h2>
      <p className="mt-1 text-xs text-faint">Amber marks the path. This is history, not a forecast.</p>
      <div className="mt-4 h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
            <XAxis dataKey="i" hide />
            <YAxis
              width={36}
              tick={{ fill: "var(--color-faint)", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                background: "var(--color-bg)",
                border: "1px solid var(--color-line)",
                borderRadius: 12,
                color: "var(--color-fg)",
              }}
              formatter={(value) => [formatX(Number(value)), "Multiplier"]}
              labelFormatter={(_, payload) => {
                const row = payload?.[0]?.payload as { label?: string } | undefined;
                return row?.label ?? "";
              }}
            />
            <Area
              type="monotone"
              dataKey="m"
              stroke="var(--color-amber)"
              fill="var(--color-amber)"
              fillOpacity={0.18}
              strokeWidth={2}
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}

function HistoryList({ rounds }: { rounds: Round[] }) {
  const rows = [...rounds].reverse().slice(0, 80);
  return (
    <section className="overflow-hidden rounded-card border border-line bg-surface">
      <div className="border-b border-line px-4 py-3">
        <h2 className="text-sm font-medium">Newest first</h2>
        <p className="text-xs text-faint">{rows.length} shown · times in UTC</p>
      </div>
      <ul>
        {rows.map((round) => (
          <li
            key={round.id}
            className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 last:border-b-0"
          >
            <span className="num text-xs text-muted">{formatWhen(round.at)}</span>
            <span className={`num text-base ${tone(round.multiplier)}`}>{formatX(round.multiplier)}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function ImportPanel({
  draft,
  notice,
  onDraft,
  onFile,
  onIngest,
  onClear,
  onSample,
  onDownload,
  hasRounds,
}: {
  draft: string;
  notice: string;
  onDraft: (value: string) => void;
  onFile: (file: File | undefined, mode: "replace" | "add") => void;
  onIngest: (text: string, mode: "replace" | "add") => void;
  onClear: () => void;
  onSample: () => void;
  onDownload: () => void;
  hasRounds: boolean;
}) {
  return (
    <div className="space-y-4">
      <section className="rounded-card border border-line bg-surface p-4">
        <h2 className="text-base font-semibold">Bring a log over</h2>
        <p className="mt-1 text-sm text-muted">
          Drop <span className="num">aviator_rounds.csv</span> from the desktop recorder, or paste multipliers.
          The file stays in this browser — it is not uploaded.
        </p>
        <label className="mt-4 flex min-h-14 cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-line bg-bg-deep text-sm">
          <Upload size={16} />
          Choose CSV
          <input
            type="file"
            accept=".csv,text/csv,text/plain"
            className="sr-only"
            onChange={(event) => onFile(event.target.files?.[0], "replace")}
          />
        </label>
        <textarea
          value={draft}
          onChange={(event) => onDraft(event.target.value)}
          placeholder={"2026-11-09T21:28:26+03:00,1.15x\n2.41x\n8.90x"}
          className="num mt-3 min-h-36 w-full rounded-xl border border-line bg-bg-deep p-3 text-sm text-fg outline-none"
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => onIngest(draft, "replace")}
            className="min-h-11 rounded-xl bg-amber px-4 text-sm font-medium text-amber-ink"
          >
            Replace log
          </button>
          <button
            type="button"
            onClick={() => onIngest(draft, "add")}
            className="min-h-11 rounded-xl border border-line px-4 text-sm"
          >
            Add to log
          </button>
        </div>
        {notice ? <p className="mt-3 text-sm text-mint">{notice}</p> : null}
      </section>

      <section className="grid gap-2 sm:grid-cols-3">
        <button type="button" onClick={onDownload} disabled={!hasRounds} className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface text-sm disabled:opacity-40">
          <Download size={16} /> Export CSV
        </button>
        <button type="button" onClick={onSample} className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface text-sm">
          <RotateCcw size={16} /> Sample log
        </button>
        <button type="button" onClick={onClear} className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-line bg-surface text-sm text-coral">
          <Trash2 size={16} /> Clear
        </button>
      </section>
    </div>
  );
}
