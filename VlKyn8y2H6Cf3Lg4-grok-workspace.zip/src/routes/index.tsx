import { createFileRoute } from "@tanstack/react-router";
import { RoundLog } from "@/components/round-log";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <RoundLog />;
}
